package com.cg.lms.exception;

public class LoanException extends Exception 
{
	public LoanException(String msg)
	{
		super(msg);
	}
}
